﻿<!DOCTYPE html>
<html>
<head>
    <title>About our project</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="assets/MyStyle.css" rel="stylesheet">
    <script src="js/header.js" defer></script>
</head>
<body>
    <div style="padding: 10px;">
        <h3>
            Who we are
        </h3>
    </div>
    <div style="display: flex; justify-content: center; align-items: center;">

        <div style="text-align:center">
            <img src="images/About1.jpg" alt="Pulpit rock" width="70%" >
            <p>UNICEF works in over 190 countries and territories to protect the rights of every child.</p>
        </div>
    </div>
    <script src="js/footer.js" defer></script>
</body>
</html>
