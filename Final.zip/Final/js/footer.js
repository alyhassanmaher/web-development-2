document.body.insertAdjacentHTML(
    'beforeend',
    `
    <link href="assets/MyStyle.css" rel="stylesheet" />
    <footer class="footer">
        <p><b>Contact Us:</b> Contact us at <a href="mailto:contact@unicef.org">contact@unicef.org</a></p>
        <p>&copy; 2025 UNICEF. All Rights Reserved.</p>
    </footer>
    `
);