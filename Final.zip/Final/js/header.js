document.body.insertAdjacentHTML(
    'afterbegin',
    `
    <header>
        <div style="padding:10px; text-align: center; background: white;">
            <img src="images/Logo.jpg" height="50" alt="Logo">
        </div>
        <div class="navbar">
            <a href="Home.php">HOME</a>
            <a href="About.php">About UNICEF</a>
            <a href="Donate.php">Donate</a>
            <a href="Contact.php">Contact us</a>
            <a href="register.php">Register</a>
            <a href="Login_Form.php">Login</a>
            <a href="admin_login.php">Admin Login</a>
            <a href="Activities.php">Activities</a>
            <a href="products.php">Products</a>
            <a href="order_history.php">Order History</a>
        </div>
    </header>
    `
);
